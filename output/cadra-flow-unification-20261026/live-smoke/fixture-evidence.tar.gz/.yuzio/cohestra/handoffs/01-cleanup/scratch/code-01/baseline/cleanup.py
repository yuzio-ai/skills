def greeting(name):
    return "hello " + name

def unused_legacy():
    return "obsolete"

---
{
  "protocol": "0.10",
  "slug": "02-fix-counter",
  "title": "02-fix-counter",
  "revision": 1,
  "preparation": "ready",
  "priority": "medium",
  "dependencies": [],
  "flow": "fix",
  "execution_policy": {
    "stop_queue_on_failure": false
  },
  "cohestra_task": ".yuzio/cohestra/handoffs/02-fix-counter/",
  "revision_base": null,
  "changed_fields": [],
  "requirement": "Located defect F-counter: count_up_to(0) returns 1; count_up_to(n) must return n for n >= 0, counting nonnegative integers below n. Fix fix_counter.py only; run python3 -B -m unittest test_fix_counter -v. Preserve signature. No other task changes or commits/push.",
  "ready_gate": {
    "revision": 1,
    "at": "2026-10-26T12:15:30.916869+00:00",
    "checks": {
      "objective": "passed",
      "scope": "passed",
      "acceptance": "passed",
      "human_decisions": "passed",
      "inputs": "passed",
      "dependencies": "passed",
      "start": "passed",
      "flow": "passed"
    },
    "evidence": "Explicit temporary fixture authorization; finite file scope and AC; inputs exist; no dependencies; no prior Run or Cohestra; start stage and allowed validated."
  }
}
---

# 02-fix-counter

## Requirement

Located defect F-counter: count_up_to(0) returns 1; count_up_to(n) must return n for n >= 0, counting nonnegative integers below n. Fix fix_counter.py only; run python3 -B -m unittest test_fix_counter -v. Preserve signature. No other task changes or commits/push.

## Binding and Ready Gate

No prior Cohestra delivery or Run. Eight checks in header passed from actual fixture and explicit parent authorization. Created 2026-10-26T12:15:30.916869+00:00 with Cadra0.10.0/protocol0.10.

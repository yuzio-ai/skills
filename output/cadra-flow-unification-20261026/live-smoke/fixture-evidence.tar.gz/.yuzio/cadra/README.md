# Temporary live smoke Cadra context
Cadra 0.10.0 / protocol 0.10.
